# Printora Product Image & Details Pack

This ZIP contains 8 product image assets and editable product catalog details.

## Contents
- `images/` — individual JPEG product photos
- `products.csv` — spreadsheet-friendly product names, descriptions, SKUs, categories, suggested variants, materials, print methods, and image paths
- `product_catalog.json` — the same catalog data in JSON format

## Product list
1. Ceramic Mug
2. Canvas Tote Bag
3. Classic T-Shirt
4. Premium Hoodie
5. Phone Case
6. Botanical Art Poster
7. Coastal Canvas Print
8. Decorative Pillow

## Important
These are generated visual mockup assets for catalog/demo use. Product dimensions, materials, available variants, print methods, prices, stock, and fulfillment details are suggestions, not verified supplier specifications. Confirm them before publishing or accepting orders.

## Suggested import mapping
- Product name: `name`
- Slug: `slug`
- SKU: `sku`
- Category: `category`
- Description: `description`
- Product image: `image`

The image paths are relative to this ZIP's root folder.
